export class Customer{
    customerNumber;
    firstName;
    lastName;
    birthDate;
    username;
    password;
    phoneNumber;
    phoneType;
}