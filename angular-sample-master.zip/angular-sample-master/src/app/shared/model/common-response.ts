export class CommonResponse<T>{
    responseCode : string;
    responseMessage : string;
    data : T;
}