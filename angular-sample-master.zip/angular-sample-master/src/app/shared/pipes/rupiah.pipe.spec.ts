import { RupiahPipe } from './rupiah.pipe';

describe('RupiahPipe', () => {
  it('create an instance', () => {
    const pipe = new RupiahPipe();
    expect(pipe).toBeTruthy();
  });
});
