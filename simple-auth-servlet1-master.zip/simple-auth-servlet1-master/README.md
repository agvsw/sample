**Simple Authentication Web App**

>  This is simple example of Authentication Web App using Servlet and Cookies