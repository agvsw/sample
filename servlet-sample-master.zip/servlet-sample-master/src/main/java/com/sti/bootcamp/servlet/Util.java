package com.sti.bootcamp.servlet;

public class Util {
	public static ThreadLocal<String> globalString = new ThreadLocal<String>();
	public static String globalStaticString;
}
